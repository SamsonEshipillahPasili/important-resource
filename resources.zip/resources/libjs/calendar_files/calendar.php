<link rel="stylesheet" href="calendar_files/winter.css" />
<script type="text/javascript" src="calendar_files/zapatec.js"></script>
<script type="text/javascript" src="calendar_files/calendar.js"></script>
<script type="text/javascript" src="calendar_files/calendar-en.js"></script>

<table cellpadding="0" cellspacing="0" border="0">
<tr>
	<td><input type="text" id="fromDate" name="fromDate"  readonly class="fields" size="10" /></td>
	<td>&nbsp;<input type="image" title="From date" align="absmiddle" src="calendar_files/calendar4.gif" id="trigger01" onmouseover="this.style.cursor='pointer'" onmouseout="this.style.cursor='default'"></td>
</tr>
</table>
<script type="text/javascript">
//<![CDATA[
	Zapatec.Calendar.setup({
		weekNumbers       : false,
		step              : 5,
		electric          : false,
		inputField        : "fromDate",
		button            : "trigger01",
		ifFormat          : "%Y-%m-%d",
		daFormat          : "%Y-%m-%d"
	});
//]]>
</script>